/**
 * Script pour la page de login administrateur
 */

// Attendre que le DOM soit chargé
document.addEventListener('DOMContentLoaded', function() {
    // Vérifier si l'utilisateur est déjà connecté
    if (isLoggedIn()) {
        // Rediriger vers la page d'administration
        window.location.href = 'gestion-courses.html';
        return;
    }
    
    // Initialiser le formulaire de login
    initialiserFormulaire();
});

/**
 * Vérifie si l'utilisateur est connecté
 */
function isLoggedIn() {
    const adminSession = localStorage.getItem('admin_session');
    return adminSession !== null;
}

/**
 * Initialise le formulaire de login
 */
function initialiserFormulaire() {
    const loginForm = document.getElementById('login-form');
    
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleLogin();
        });
    }
    
    // Focus automatique sur le champ username
    const usernameInput = document.getElementById('username');
    if (usernameInput) {
        usernameInput.focus();
    }
}

/**
 * Gère la connexion
 */
async function handleLogin() {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;
    const loginBtn = document.getElementById('login-btn');
    const errorMessage = document.getElementById('error-message');
    
    // Validation des champs
    if (!username || !password) {
        showError('Veuillez remplir tous les champs');
        return;
    }
    
    // Désactiver le bouton et afficher l'état de chargement
    loginBtn.disabled = true;
    loginBtn.textContent = 'Connexion en cours...';
    hideError();
    
    try {
        // Appel à l'API de login
        const response = await fetch(`${API_BASE_URL}/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                username: username,
                password: password
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Connexion réussie
            console.log('Connexion réussie:', data);
            
            // Sauvegarder la session
            localStorage.setItem('admin_session', JSON.stringify({
                admin_id: data.admin.id,
                username: data.admin.username,
                login_time: new Date().toISOString()
            }));
            
            // Afficher un message de succès
            showSuccess('Connexion réussie ! Redirection...');
            
            // Rediriger vers la page d'administration après 1 seconde
            setTimeout(() => {
                window.location.href = 'gestion-courses.html';
            }, 1000);
            
        } else {
            // Erreur de connexion
            showError(data.message || 'Identifiants incorrects');
        }
        
    } catch (error) {
        console.error('Erreur de connexion:', error);
        showError('Erreur de connexion au serveur. Vérifiez que l\'API est démarrée.');
    } finally {
        // Réactiver le bouton
        loginBtn.disabled = false;
        loginBtn.textContent = 'Se connecter';
    }
}

/**
 * Affiche un message d'erreur
 */
function showError(message) {
    const errorElement = document.getElementById('error-message');
    if (errorElement) {
        errorElement.textContent = message;
        errorElement.style.display = 'block';
    }
}

/**
 * Cache le message d'erreur
 */
function hideError() {
    const errorElement = document.getElementById('error-message');
    if (errorElement) {
        errorElement.style.display = 'none';
    }
}

/**
 * Affiche un message de succès
 */
function showSuccess(message) {
    const errorElement = document.getElementById('error-message');
    if (errorElement) {
        errorElement.textContent = message;
        errorElement.style.background = '#d4edda';
        errorElement.style.color = '#155724';
        errorElement.style.display = 'block';
    }
}

/**
 * Fonction utilitaire pour la déconnexion (sera utilisée dans gestion-courses.js)
 */
function logout() {
    localStorage.removeItem('admin_session');
    window.location.href = 'login.html';
}