/**
 * Configuration de l'API pour le site de course d'endurance
 * Ce fichier contient les paramètres et fonctions communes pour interagir avec l'API
 */

// URL de base de l'API
const API_BASE_URL = 'http://localhost:5000/api';

// Fonctions utilitaires pour les appels API
const API = {
    /**
     * Effectue une requête GET vers l'API
     * @param {string} endpoint - Point de terminaison de l'API (sans le préfixe API_BASE_URL)
     * @param {Object} params - Paramètres de requête (optionnel)
     * @returns {Promise<Object>} - Réponse de l'API
     */
    async get(endpoint, params = {}) {
        try {
            // Construire l'URL avec les paramètres de requête
            let url = `${API_BASE_URL}${endpoint}`;
            
            // Ajouter les paramètres de requête s'il y en a
            if (Object.keys(params).length > 0) {
                const queryParams = new URLSearchParams();
                for (const key in params) {
                    queryParams.append(key, params[key]);
                }
                url += `?${queryParams.toString()}`;
            }
            
            // Effectuer la requête
            const response = await fetch(url);
            
            // Vérifier si la requête a réussi
            if (!response.ok) {
                throw new Error(`Erreur HTTP: ${response.status}`);
            }
            
            // Retourner les données JSON
            return await response.json();
        } catch (error) {
            console.error(`Erreur lors de la requête GET vers ${endpoint}:`, error);
            throw error;
        }
    },
    
    /**
     * Effectue une requête POST vers l'API
     * @param {string} endpoint - Point de terminaison de l'API (sans le préfixe API_BASE_URL)
     * @param {Object} data - Données à envoyer
     * @returns {Promise<Object>} - Réponse de l'API
     */
    async post(endpoint, data) {
        try {
            console.log(`Envoi de données vers ${endpoint}:`, data);
            
            const response = await fetch(`${API_BASE_URL}${endpoint}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            });
            
            // Afficher les informations de la réponse pour le débogage
            console.log(`Réponse du serveur (${endpoint}):`, {
                status: response.status,
                statusText: response.statusText,
                headers: Object.fromEntries([...response.headers])
            });
            
            // Récupérer le corps de la réponse
            const responseText = await response.text();
            console.log(`Corps de la réponse (${endpoint}):`, responseText);
            
            // Essayer de parser le JSON
            let responseData;
            try {
                responseData = JSON.parse(responseText);
            } catch (e) {
                console.error(`Erreur lors du parsing JSON (${endpoint}):`, e);
                throw new Error(`Réponse non-JSON reçue: ${responseText}`);
            }
            
            // Vérifier si la requête a réussi
            if (!response.ok) {
                console.error(`Erreur HTTP ${response.status} (${endpoint}):`, responseData);
                throw new Error(responseData.message || `Erreur HTTP: ${response.status}`);
            }
            
            // Retourner les données JSON
            return responseData;
        } catch (error) {
            console.error(`Erreur lors de la requête POST vers ${endpoint}:`, error);
            throw error;
        }
    },
    
    /**
     * Effectue une requête PUT vers l'API
     * @param {string} endpoint - Point de terminaison de l'API (sans le préfixe API_BASE_URL)
     * @param {Object} data - Données à envoyer
     * @returns {Promise<Object>} - Réponse de l'API
     */
    async put(endpoint, data) {
        try {
            const response = await fetch(`${API_BASE_URL}${endpoint}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            });
            
            // Vérifier si la requête a réussi
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || `Erreur HTTP: ${response.status}`);
            }
            
            // Retourner les données JSON
            return await response.json();
        } catch (error) {
            console.error(`Erreur lors de la requête PUT vers ${endpoint}:`, error);
            throw error;
        }
    },
    
    /**
     * Effectue une requête DELETE vers l'API
     * @param {string} endpoint - Point de terminaison de l'API (sans le préfixe API_BASE_URL)
     * @returns {Promise<Object>} - Réponse de l'API
     */
    async delete(endpoint) {
        try {
            const response = await fetch(`${API_BASE_URL}${endpoint}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                }
            });
            
            // Vérifier si la requête a réussi
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || `Erreur HTTP: ${response.status}`);
            }
            
            // Retourner les données JSON
            return await response.json();
        } catch (error) {
            console.error(`Erreur lors de la requête DELETE vers ${endpoint}:`, error);
            throw error;
        }
    }
};

// Fonctions spécifiques pour les entités principales
const CourseAPI = {
    /**
     * Récupère toutes les courses
     * @param {boolean} activeOnly - Si true, ne récupère que les courses actives
     * @returns {Promise<Array>} - Liste des courses
     */
    async getAll(activeOnly = false) {
        const response = await API.get('/courses', { active_only: activeOnly });
        return response.data;
    },
    
    /**
     * Récupère une course par son ID
     * @param {number} courseId - ID de la course
     * @returns {Promise<Object>} - Détails de la course
     */
    async getById(courseId) {
        const response = await API.get(`/courses/${courseId}`);
        return response.data;
    },
    
    /**
     * Crée une nouvelle course
     * @param {Object} courseData - Données de la course
     * @returns {Promise<Object>} - Réponse de l'API
     */
    async create(courseData) {
        return await API.post('/courses', courseData);
    },
    
    /**
     * Met à jour une course existante
     * @param {number} courseId - ID de la course
     * @param {Object} courseData - Données de la course
     * @returns {Promise<Object>} - Réponse de l'API
     */
    async update(courseId, courseData) {
        return await API.put(`/courses/${courseId}`, courseData);
    },
    
    /**
     * Supprime une course
     * @param {number} courseId - ID de la course
     * @returns {Promise<Object>} - Réponse de l'API
     */
    async delete(courseId) {
        return await API.delete(`/courses/${courseId}`);
    },
    
    /**
     * Récupère tous les coureurs inscrits à une course
     * @param {number} courseId - ID de la course
     * @returns {Promise<Array>} - Liste des coureurs
     */
    async getCoureurs(courseId) {
        const response = await API.get(`/courses/${courseId}/coureurs`);
        return response.data;
    },
    
    /**
     * Ajoute un coureur à une course
     * @param {number} courseId - ID de la course
     * @param {Object} coureurData - Données du coureur
     * @returns {Promise<Object>} - Réponse de l'API
     */
    async addCoureur(courseId, coureurData) {
        try {
            // Vérifier que les données requises sont présentes
            if (!coureurData.nom || !coureurData.prenom || !coureurData.numero_rfid) {
                throw new Error('Données de coureur incomplètes');
            }
            
            // Nettoyer les données
            const cleanData = {
                nom: coureurData.nom.trim(),
                prenom: coureurData.prenom.trim(),
                age: parseInt(coureurData.age) || 20,
                poids: parseFloat(coureurData.poids) || 70,
                // S'assurer que le numéro RFID est un nombre entier
                numero_rfid: parseInt(coureurData.numero_rfid)
            };
            
            // Vérifier que le numéro RFID est valide
            if (isNaN(cleanData.numero_rfid) || cleanData.numero_rfid <= 0) {
                throw new Error('Numéro RFID invalide');
            }
            
            // Ajouter les champs optionnels s'ils sont présents
            if (coureurData.taille) cleanData.taille = parseFloat(coureurData.taille);
            if (coureurData.email) cleanData.email = coureurData.email.trim();
            if (coureurData.telephone) cleanData.telephone = coureurData.telephone.trim();
            if (coureurData.statut) cleanData.statut = coureurData.statut;
            if (coureurData.informations_medicales) cleanData.informations_medicales = coureurData.informations_medicales.trim();
            
            console.log('Données nettoyées pour l\'API:', cleanData);
            
            // Simplifier l'objet pour n'envoyer que les champs requis par l'API
            const apiData = {
                nom: cleanData.nom,
                prenom: cleanData.prenom,
                age: cleanData.age,
                poids: cleanData.poids,
                numero_rfid: cleanData.numero_rfid
            };
            
            console.log('Données envoyées à l\'API:', apiData);
            
            return await API.post(`/courses/${courseId}/coureurs`, apiData);
        } catch (error) {
            console.error('Erreur lors de l\'ajout du coureur:', error);
            throw error;
        }
    },
    
    /**
     * Récupère tous les passages de badge pour une course
     * @param {number} courseId - ID de la course
     * @returns {Promise<Array>} - Liste des passages
     */
    async getPassages(courseId) {
        const response = await API.get(`/courses/${courseId}/passages`);
        return response.data;
    },
    
    /**
     * Enregistre un passage de badge
     * @param {number} courseId - ID de la course
     * @param {Object} passageData - Données du passage
     * @returns {Promise<Object>} - Réponse de l'API
     */
    async addPassage(courseId, passageData) {
        return await API.post(`/courses/${courseId}/passages`, passageData);
    }
};

const TypeCourseAPI = {
    /**
     * Récupère tous les types de course
     * @returns {Promise<Array>} - Liste des types de course
     */
    async getAll() {
        const response = await API.get('/types-course');
        return response.data;
    }
};

const CoureurAPI = {
    /**
     * Récupère tous les coureurs
     * @returns {Promise<Array>} - Liste des coureurs
     */
    async getAll() {
        const response = await API.get('/coureurs');
        return response.data;
    },
    
    /**
     * Récupère un coureur par son ID
     * @param {number} coureurId - ID du coureur
     * @returns {Promise<Object>} - Détails du coureur
     */
    async getById(coureurId) {
        const response = await API.get(`/coureurs/${coureurId}`);
        return response.data;
    }
};

const BadgeAPI = {
    /**
     * Récupère tous les badges
     * @returns {Promise<Array>} - Liste des badges
     */
    async getAll() {
        const response = await API.get('/badges');
        return response.data;
    },
    
    /**
     * Récupère un badge par son ID
     * @param {number} badgeId - ID du badge
     * @returns {Promise<Object>} - Détails du badge
     */
    async getById(badgeId) {
        const response = await API.get(`/badges/${badgeId}`);
        return response.data;
    }
};

// Fonctions utilitaires communes
const Utils = {
    /**
     * Formate une date au format français
     * @param {string} dateString - Date au format ISO
     * @returns {string} - Date formatée (ex: 01/01/2025)
     */
    formatDate(dateString) {
        if (!dateString) return '';
        const date = new Date(dateString);
        return date.toLocaleDateString('fr-FR');
    },
    
    /**
     * Obtient la description du type de course
     * @param {Object} course - Objet course
     * @returns {string} - Description du type de course
     */
    getTypeDescription(course) {
        if (!course) return '';
        
        if (course.type_nom === 'Temps') {
            const minutes = Math.floor(course.temps_total / 60);
            return `Course au temps - ${minutes} min`;
        } else if (course.type_nom === 'Distance') {
            const km = course.distance_totale / 1000;
            return `Course à la distance - ${km}km`;
        }
        
        return course.type_nom || 'Type non défini';
    },
    
    /**
     * Affiche un message d'erreur
     * @param {string} message - Message d'erreur
     * @param {Element} container - Conteneur où afficher l'erreur
     */
    showError(message, container) {
        const errorElement = document.createElement('div');
        errorElement.className = 'error-message';
        errorElement.textContent = message;
        
        container.appendChild(errorElement);
        
        // Supprimer le message après 5 secondes
        setTimeout(() => {
            errorElement.remove();
        }, 5000);
    }
};