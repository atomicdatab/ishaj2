/**
 * Script pour la gestion des courses
 * Permet de lister, modifier et supprimer les courses
 */


// Vérification de l'authentification
function checkAuthentication() {
    const adminSession = localStorage.getItem('admin_session');
    if (!adminSession) {
        // Pas connecté, rediriger vers login
        alert('Accès refusé. Vous devez vous connecter en tant qu\'administrateur.');
        window.location.href = 'login.html';
        return false;
    }
    return true;
}

// Fonction de déconnexion
function logout() {
    localStorage.removeItem('admin_session');
    window.location.href = 'login.html';
}

// Attendre que le DOM soit chargé
document.addEventListener('DOMContentLoaded', function() {
    // Charger les courses depuis l'API
    chargerCourses();
    
    // Initialiser les gestionnaires d'événements
    initialiserEvenements();
});

// Variables globales
let courses = [];
let courseIdASupprimer = null;

/**
 * Charge les courses depuis l'API
 */
async function chargerCourses() {
    try {
        // Afficher un indicateur de chargement
        const coursesContainer = document.querySelector('.courses-list');
        coursesContainer.innerHTML = '<div class="loading">Chargement des courses...</div>';
        
        // Récupérer les courses depuis l'API
        courses = await CourseAPI.getAll();
        
        // Afficher les courses
        afficherCourses(courses);
    } catch (error) {
        console.error('Erreur lors du chargement des courses:', error);
        
        // Afficher un message d'erreur
        const coursesContainer = document.querySelector('.courses-list');
        coursesContainer.innerHTML = `
            <div class="error-message">
                <h3>Erreur de chargement</h3>
                <p>Impossible de charger les courses. Vérifiez que l'API est démarrée.</p>
                <button class="btn btn-small" onclick="chargerCourses()">Réessayer</button>
            </div>
        `;
    }
}

/**
 * Affiche les courses dans la liste
 * @param {Array} courses - Liste des courses
 */
function afficherCourses(courses) {
    const coursesContainer = document.querySelector('.courses-list');
    
    // Vider le conteneur
    coursesContainer.innerHTML = '';
    
    // Si aucune course n'est disponible
    if (courses.length === 0) {
        coursesContainer.innerHTML = `
            <div class="no-courses">
                <h3>Aucune course disponible</h3>
                <p>Vous n'avez pas encore créé de course.</p>
                <a href="création.html" class="btn btn-primary">Créer une course</a>
            </div>
        `;
        return;
    }
    
    // Afficher chaque course
    courses.forEach(course => {
        const courseElement = document.createElement('div');
        courseElement.className = 'course-item';
        courseElement.dataset.courseId = course.course_id;
        
        // Déterminer le statut de la course
        const estActive = course.est_active || true; // Par défaut, considérer comme active
        const statusClass = estActive ? 'active' : 'inactive';
        const statusText = estActive ? 'Active' : 'Terminée';
        
        // Créer la description du type de course
        const typeDescription = Utils.getTypeDescription(course);
        
        // Construire le HTML de la course
        courseElement.innerHTML = `
            <div class="course-info">
                <div class="course-header">
                    <h4>${course.nom}</h4>
                    <div class="course-status ${statusClass}">${statusText}</div>
                </div>
                <div class="course-details">
                    <div class="detail-item">
                        <span class="label">Lieu :</span>
                        <span class="value">${course.lieu}</span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Type :</span>
                        <span class="value">${typeDescription}</span>
                    </div>
                </div>
            </div>
            <div class="course-actions">
                <button class="btn btn-small btn-outline" onclick="voirCourse(${course.course_id})">Voir</button>
                <button class="btn btn-small btn-warning" onclick="modifierCourse(${course.course_id})">Modifier</button>
                <button class="btn btn-small btn-danger" onclick="supprimerCourse(${course.course_id})">Supprimer</button>
            </div>
        `;
        
        coursesContainer.appendChild(courseElement);
    });
}

/**
 * Initialise les gestionnaires d'événements
 */
function initialiserEvenements() {
    // Gestionnaire pour le formulaire de modification
    const formModification = document.getElementById('form-modification');
    if (formModification) {
        formModification.addEventListener('submit', function(e) {
            e.preventDefault();
            sauvegarderModifications();
        });
    }
    
    // Gestionnaire pour le bouton de confirmation de suppression
    const btnConfirmerSuppression = document.getElementById('confirmer-suppression');
    if (btnConfirmerSuppression) {
        btnConfirmerSuppression.addEventListener('click', function() {
            confirmerSuppression();
        });
    }
}

/**
 * Affiche les détails d'une course
 * @param {number} courseId - ID de la course
 */
async function voirCourse(courseId) {
    try {
        // Récupérer les détails de la course
        const course = await CourseAPI.getById(courseId);
        
        // Rediriger vers la page de détails de la course
        window.location.href = `course.html?id=${courseId}`;
    } catch (error) {
        console.error('Erreur lors de la récupération des détails de la course:', error);
        alert('Impossible de récupérer les détails de la course. Veuillez réessayer.');
    }
}

/**
 * Ouvre le modal de modification d'une course
 * @param {number} courseId - ID de la course
 */
async function modifierCourse(courseId) {
    try {
        // Récupérer les détails de la course
        const course = await CourseAPI.getById(courseId);
        
        // Remplir le formulaire avec les données de la course
        document.getElementById('edit-nom').value = course.nom;
        document.getElementById('edit-lieu').value = course.lieu;
        
        // Sélectionner le type de course
        const selectType = document.getElementById('edit-type');
        if (course.type_nom === 'Temps') {
            selectType.value = 'temps';
        } else if (course.type_nom === 'Distance') {
            selectType.value = 'distance';
        } else {
            selectType.value = 'relais';
        }
        
        // Stocker l'ID de la course dans un attribut data
        document.getElementById('form-modification').dataset.courseId = courseId;
        
        // Afficher le modal
        document.getElementById('modal-modification').style.display = 'block';
    } catch (error) {
        console.error('Erreur lors de la récupération des détails de la course:', error);
        alert('Impossible de récupérer les détails de la course. Veuillez réessayer.');
    }
}

/**
 * Ferme le modal de modification
 */
function fermerModal() {
    document.getElementById('modal-modification').style.display = 'none';
}

/**
 * Sauvegarde les modifications d'une course
 */
async function sauvegarderModifications() {
    try {
        // Récupérer l'ID de la course
        const courseId = document.getElementById('form-modification').dataset.courseId;
        
        // Récupérer les données du formulaire
        const nom = document.getElementById('edit-nom').value;
        const lieu = document.getElementById('edit-lieu').value;
        const typeValue = document.getElementById('edit-type').value;
        
        // Déterminer le type_id en fonction de la valeur sélectionnée
        let type_id = 1; // Par défaut, type Temps
        if (typeValue === 'distance') {
            type_id = 2;
        } else if (typeValue === 'relais') {
            type_id = 3;
        }
        
        // Préparer les données à envoyer
        const courseData = {
            nom: nom,
            lieu: lieu,
            type_id: type_id
        };
        
        // Envoyer les modifications à l'API
        const response = await CourseAPI.update(courseId, courseData);
        
        if (response.success) {
            // Fermer le modal
            fermerModal();
            
            // Recharger les courses
            chargerCourses();
            
            // Afficher un message de succès
            alert('Course modifiée avec succès !');
        } else {
            alert('Erreur lors de la modification: ' + response.message);
        }
    } catch (error) {
        console.error('Erreur lors de la sauvegarde des modifications:', error);
        alert('Erreur lors de la sauvegarde des modifications. Veuillez réessayer.');
    }
}

/**
 * Ouvre le modal de confirmation de suppression
 * @param {number} courseId - ID de la course
 */
function supprimerCourse(courseId) {
    // Trouver la course correspondante
    const course = courses.find(c => c.course_id == courseId);
    
    if (course) {
        // Stocker l'ID de la course à supprimer
        courseIdASupprimer = courseId;
        
        // Afficher le nom de la course dans le modal
        document.getElementById('course-nom-suppression').textContent = course.nom;
        
        // Afficher le modal
        document.getElementById('modal-suppression').style.display = 'block';
    } else {
        alert('Course introuvable.');
    }
}

/**
 * Ferme le modal de confirmation de suppression
 */
function fermerModalSuppression() {
    document.getElementById('modal-suppression').style.display = 'none';
    courseIdASupprimer = null;
}

/**
 * Confirme la suppression d'une course
 */
async function confirmerSuppression() {
    if (!courseIdASupprimer) {
        fermerModalSuppression();
        return;
    }
    
    try {
        // Envoyer la demande de suppression à l'API
        const response = await CourseAPI.delete(courseIdASupprimer);
        
        if (response.success) {
            // Fermer le modal
            fermerModalSuppression();
            
            // Recharger les courses
            chargerCourses();
            
            // Afficher un message de succès
            alert('Course supprimée avec succès !');
        } else {
            alert('Erreur lors de la suppression: ' + response.message);
        }
    } catch (error) {
        console.error('Erreur lors de la suppression de la course:', error);
        alert('Erreur lors de la suppression de la course. Veuillez réessayer.');
    }
}