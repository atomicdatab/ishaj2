/**
 * Script de débogage pour identifier les problèmes
 */

console.log('Script de débogage chargé');

// Vérifier si le script est chargé après api-config.js
console.log('API_BASE_URL disponible:', typeof API_BASE_URL !== 'undefined');
console.log('CourseAPI disponible:', typeof CourseAPI !== 'undefined');

// Fonction pour inspecter le HTML
function inspectHTML() {
    // Rechercher les scripts inline
    const scripts = document.querySelectorAll('script:not([src])');
    console.log('Nombre de scripts inline trouvés:', scripts.length);
    
    scripts.forEach((script, index) => {
        console.log(`Script inline #${index + 1}:`, script.textContent.substring(0, 100) + '...');
        
        // Vérifier si le script contient une référence à formData
        if (script.textContent.includes('formData')) {
            console.log(`Le script #${index + 1} contient une référence à formData`);
        }
    });
}

// Exécuter l'inspection après le chargement complet de la page
window.addEventListener('load', inspectHTML);