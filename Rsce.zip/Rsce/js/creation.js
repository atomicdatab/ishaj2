/**
 * Script pour la page de création de course
 * Permet de créer une nouvelle course
 */

// Attendre que le DOM soit chargé
document.addEventListener('DOMContentLoaded', function() {
    // Initialiser les gestionnaires d'événements
    initialiserEvenements();
    
    // Charger les types de course
    chargerTypesCourse();
});

/**
 * Initialise les gestionnaires d'événements
 */
function initialiserEvenements() {
    // Gestionnaire pour la sélection du type de course
    document.getElementById('race-type-time')?.addEventListener('click', function() {
        selectRaceType(this, 'time');
    });
    
    document.getElementById('race-type-distance')?.addEventListener('click', function() {
        selectRaceType(this, 'distance');
    });
    
    // Gestionnaire pour le bouton de réinitialisation
    document.getElementById('reset-form')?.addEventListener('click', function() {
        document.getElementById('create-race-form').reset();
        document.querySelectorAll('.race-type').forEach(el => {
            el.classList.remove('selected');
        });
    });
    
    // Gestionnaire pour la soumission du formulaire
    document.getElementById('create-race-form')?.addEventListener('submit', function(e) {
        e.preventDefault();
        creerCourse();
    });
    
    // Gestionnaire pour les sections dépliables
    document.querySelectorAll('.toggle-header').forEach(header => {
        header.addEventListener('click', function() {
            const contentId = this.getAttribute('onclick').match(/toggleSection\('(.+?)'\)/)[1];
            toggleSection(contentId);
        });
    });
}

/**
 * Charge les types de course depuis l'API
 */
async function chargerTypesCourse() {
    try {
        const types = await TypeCourseAPI.getAll();
        console.log('Types de course chargés:', types);
    } catch (error) {
        console.error('Erreur lors du chargement des types de course:', error);
    }
}

/**
 * Sélectionne un type de course
 * @param {Element} element - Élément HTML du type de course
 * @param {string} type - Type de course (time ou distance)
 */
function selectRaceType(element, type) {
    // Désélectionner tous les types
    document.querySelectorAll('.race-type').forEach(el => {
        el.classList.remove('selected');
    });
    
    // Sélectionner le type choisi
    element.classList.add('selected');
    
    // Cacher tous les paramètres
    document.getElementById('time-settings')?.classList.remove('active');
    document.getElementById('distance-settings')?.classList.remove('active');
    
    // Afficher les paramètres correspondants
    if (type === 'time') {
        document.getElementById('time-settings')?.classList.add('active');
    } else if (type === 'distance') {
        document.getElementById('distance-settings')?.classList.add('active');
    }
}

/**
 * Affiche ou masque une section
 * @param {string} id - ID de la section à afficher/masquer
 */
function toggleSection(id) {
    const content = document.getElementById(id);
    if (content) {
        content.classList.toggle('active');
    }
}

/**
 * Crée une nouvelle course
 */
async function creerCourse() {
    // Vérifier qu'un type de course est sélectionné
    const selectedType = document.querySelector('.race-type.selected');
    if (!selectedType) {
        alert('Veuillez sélectionner un type de course.');
        return;
    }
    
    // Récupérer les données du formulaire
    const formData = {
        nom: document.getElementById('race-name').value,
        lieu: document.getElementById('race-location').value,
        type_id: selectedType.id === 'race-type-time' ? 1 : 2, // 1 = temps, 2 = distance
        distance_par_tour: 400 // valeur par défaut
    };
    
    // Ajouter les champs spécifiques selon le type
    if (selectedType.id === 'race-type-time') {
        const timeDuration = document.getElementById('time-duration');
        formData.temps_total = parseInt(timeDuration?.value) || 30;
    } else {
        const distanceTotal = document.getElementById('distance-total');
        formData.distance_totale = parseInt(distanceTotal?.value) || 5000;
    }
    
    console.log('Envoi des données:', formData);
    
    try {
        // Envoyer les données à l'API
        const response = await CourseAPI.create(formData);
        
        console.log('Réponse API:', response);
        
        if (response.success) {
            alert('Course créée avec succès ! 🎉');
            
            // Réinitialiser le formulaire
            document.getElementById('create-race-form').reset();
            document.querySelectorAll('.race-type').forEach(el => {
                el.classList.remove('selected');
            });
            
        } else {
            alert('Erreur lors de la création: ' + (response.message || 'Erreur inconnue'));
        }
    } catch (error) {
        console.error('Erreur complète:', error);
        alert('Erreur de connexion avec le serveur. Vérifiez que l\'API est démarrée sur http://localhost:5000');
    }
}