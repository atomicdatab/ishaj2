/**
 * Script pour la page des courses
 * Permet d'afficher et de filtrer les courses disponibles
 */

// Attendre que le DOM soit chargé
document.addEventListener('DOMContentLoaded', function() {
    // Charger les courses depuis l'API
    chargerCourses();
    
    // Initialiser les filtres
    initialiserFiltres();
});

// Variables globales
let courses = [];

/**
 * Charge les courses depuis l'API
 */
async function chargerCourses() {
    try {
        // Récupérer les courses depuis l'API
        courses = await CourseAPI.getAll();
        
        // Afficher les courses
        afficherCourses(courses);
        
        // Initialiser les options de filtre
        initialiserOptionsFiltres(courses);
    } catch (error) {
        console.error('Erreur lors du chargement des courses:', error);
        afficherMessageErreur();
    }
}

/**
 * Affiche les courses dans la grille
 * @param {Array} courses - Liste des courses
 */
function afficherCourses(courses) {
    const mainContent = document.querySelector('.main-content');
    
    // Supprimer l'ancien contenu de courses s'il existe
    const existingCourses = document.querySelector('.courses-container');
    if (existingCourses) {
        existingCourses.remove();
    }
    
    // Si aucune course n'est disponible
    if (courses.length === 0) {
        const noCoursesHTML = `
            <div class="courses-container">
                <div class="no-courses">
                    <h3>Aucune course disponible</h3>
                    <p>Il n'y a actuellement aucune course programmée.</p>
                    <a href="création.html" class="btn">Créer une course</a>
                </div>
            </div>
        `;
        mainContent.insertAdjacentHTML('beforeend', noCoursesHTML);
        return;
    }
    
    // Créer le conteneur de courses
    const coursesHTML = `
        <div class="courses-container">
            <div class="courses-grid">
                ${courses.map(course => createCourseCard(course)).join('')}
            </div>
        </div>
    `;
    
    mainContent.insertAdjacentHTML('beforeend', coursesHTML);
}

/**
 * Crée une carte de course
 * @param {Object} course - Données de la course
 * @returns {string} - HTML de la carte
 */
function createCourseCard(course) {
    const typeDescription = Utils.getTypeDescription(course);
    const statusClass = course.est_active ? 'active' : 'inactive';
    const statusText = course.est_active ? 'Inscriptions ouvertes' : 'Course terminée';
    
    return `
        <div class="course-card" data-type="${course.type_nom?.toLowerCase()}" data-location="${course.lieu?.toLowerCase()}">
            <div class="course-header">
                <h3>${course.nom}</h3>
                <div class="course-status ${statusClass}">${statusText}</div>
            </div>
            <div class="course-info">
                <div class="info-item">
                    <span class="icon">📍</span>
                    <span>${course.lieu}</span>
                </div>
                <div class="info-item">
                    <span class="icon">${course.type_nom === 'Temps' ? '⏱️' : '📏'}</span>
                    <span>${typeDescription}</span>
                </div>
            </div>
            <div class="course-actions">
                <a href="inscription.html?course=${course.course_id}" class="btn btn-primary">S'inscrire</a>
                <button class="btn btn-outline" onclick="voirDetailsCourse(${course.course_id})">Détails</button>
            </div>
        </div>
    `;
}

/**
 * Affiche un message d'erreur
 */
function afficherMessageErreur() {
    const mainContent = document.querySelector('.main-content');
    
    // Supprimer l'ancien contenu de courses s'il existe
    const existingCourses = document.querySelector('.courses-container');
    if (existingCourses) {
        existingCourses.remove();
    }
    
    const errorHTML = `
        <div class="courses-container">
            <div class="error-message">
                <h3>Erreur de chargement</h3>
                <p>Impossible de charger les courses. Vérifiez que l'API est démarrée.</p>
                <button class="btn" onclick="chargerCourses()">Réessayer</button>
            </div>
        </div>
    `;
    
    mainContent.insertAdjacentHTML('beforeend', errorHTML);
}

/**
 * Initialise les options de filtre
 * @param {Array} courses - Liste des courses
 */
function initialiserOptionsFiltres(courses) {
    // Récupérer les lieux uniques
    const lieux = [...new Set(courses.map(course => course.lieu))];
    
    // Remplir le sélecteur de lieux
    const selectLieu = document.getElementById('filter-location');
    selectLieu.innerHTML = '<option value="all">Tous les lieux</option>';
    
    lieux.forEach(lieu => {
        if (lieu) {
            const option = document.createElement('option');
            option.value = lieu.toLowerCase();
            option.textContent = lieu;
            selectLieu.appendChild(option);
        }
    });
}

/**
 * Initialise les filtres
 */
function initialiserFiltres() {
    // Récupérer les éléments de filtre
    const filterType = document.getElementById('filter-type');
    const filterDate = document.getElementById('filter-date');
    const filterLocation = document.getElementById('filter-location');
    const btnFilter = document.querySelector('.filter-buttons .btn:last-child');
    const btnReset = document.querySelector('.filter-buttons .btn:first-child');
    
    // Ajouter les gestionnaires d'événements
    if (btnFilter) {
        btnFilter.addEventListener('click', appliquerFiltres);
    }
    
    if (btnReset) {
        btnReset.addEventListener('click', reinitialiserFiltres);
    }
}

/**
 * Applique les filtres sélectionnés
 */
function appliquerFiltres() {
    // Récupérer les valeurs des filtres
    const typeValue = document.getElementById('filter-type').value;
    const dateValue = document.getElementById('filter-date').value;
    const locationValue = document.getElementById('filter-location').value;
    
    // Filtrer les courses
    let coursesFiltrees = [...courses];
    
    // Filtre par type
    if (typeValue !== 'all') {
        coursesFiltrees = coursesFiltrees.filter(course => {
            if (typeValue === 'time' && course.type_nom === 'Temps') return true;
            if (typeValue === 'distance' && course.type_nom === 'Distance') return true;
            return false;
        });
    }
    
    // Filtre par lieu
    if (locationValue !== 'all') {
        coursesFiltrees = coursesFiltrees.filter(course => 
            course.lieu && course.lieu.toLowerCase().includes(locationValue)
        );
    }
    
    // Afficher les courses filtrées
    afficherCourses(coursesFiltrees);
}

/**
 * Réinitialise les filtres
 */
function reinitialiserFiltres() {
    // Réinitialiser les valeurs des filtres
    document.getElementById('filter-type').value = 'all';
    document.getElementById('filter-date').value = '';
    document.getElementById('filter-location').value = 'all';
    
    // Afficher toutes les courses
    afficherCourses(courses);
}

/**
 * Affiche les détails d'une course
 * @param {number} courseId - ID de la course
 */
async function voirDetailsCourse(courseId) {
    try {
        // Récupérer les détails de la course
        const course = await CourseAPI.getById(courseId);
        
        // Créer le modal de détails
        const modalHTML = `
            <div id="modal-details" class="modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>${course.nom}</h3>
                        <span class="close" onclick="fermerModalDetails()">&times;</span>
                    </div>
                    <div class="modal-body">
                        <div class="course-details-grid">
                            <div class="detail-group">
                                <h4>Informations générales</h4>
                                <div class="detail-item">
                                    <span class="label">Lieu :</span>
                                    <span class="value">${course.lieu}</span>
                                </div>
                                <div class="detail-item">
                                    <span class="label">Type :</span>
                                    <span class="value">${Utils.getTypeDescription(course)}</span>
                                </div>
                            </div>
                            
                            <div class="detail-group">
                                <h4>Paramètres</h4>
                                ${course.type_nom === 'Temps' ? `
                                    <div class="detail-item">
                                        <span class="label">Durée :</span>
                                        <span class="value">${Math.floor(course.temps_total / 60)} minutes</span>
                                    </div>
                                ` : ''}
                                ${course.type_nom === 'Distance' ? `
                                    <div class="detail-item">
                                        <span class="label">Distance :</span>
                                        <span class="value">${course.distance_totale / 1000} km</span>
                                    </div>
                                ` : ''}
                                <div class="detail-item">
                                    <span class="label">Distance par tour :</span>
                                    <span class="value">${course.distance_par_tour} m</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <a href="inscription.html?course=${course.course_id}" class="btn btn-primary">S'inscrire</a>
                        <button class="btn btn-secondary" onclick="fermerModalDetails()">Fermer</button>
                    </div>
                </div>
            </div>
        `;
        
        // Ajouter le modal au document
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        
        // Afficher le modal
        document.getElementById('modal-details').style.display = 'block';
    } catch (error) {
        console.error('Erreur lors de la récupération des détails de la course:', error);
        alert('Impossible de récupérer les détails de la course. Veuillez réessayer.');
    }
}

/**
 * Ferme le modal de détails
 */
function fermerModalDetails() {
    const modal = document.getElementById('modal-details');
    if (modal) {
        modal.remove();
    }
}