/**
 * Script pour la page d'inscription
 * Permet aux utilisateurs de s'inscrire à une course
 */

// Attendre que le DOM soit chargé
document.addEventListener('DOMContentLoaded', function() {
    // Tester la connexion à l'API
    testerConnexionAPI();
    
    // Charger les courses disponibles
    chargerCoursesDisponibles();
    
    // Initialiser le formulaire
    initialiserFormulaire();
});

/**
 * Teste la connexion à l'API
 */
async function testerConnexionAPI() {
    try {
        // Tenter de récupérer les types de course (requête simple)
        const response = await fetch(`${API_BASE_URL}/types-course`);
        
        if (response.ok) {
            console.log('✅ Connexion à l\'API réussie');
            alert('✅ Connexion à l\'API réussie');
            
            // Afficher les données reçues
            const data = await response.json();
            console.log('Types de course:', data);
        } else {
            console.warn('⚠️ L\'API est accessible mais a retourné une erreur:', response.status, response.statusText);
            alert(`⚠️ L'API est accessible mais a retourné une erreur: ${response.status} ${response.statusText}`);
        }
    } catch (error) {
        console.error('❌ Impossible de se connecter à l\'API:', error);
        alert(`❌ Impossible de se connecter à l'API: ${error.message}`);
        
        // Afficher un message d'avertissement dans l'interface
        const formSection = document.querySelector('.form-section');
        if (formSection) {
            const warningElement = document.createElement('div');
            warningElement.className = 'api-warning';
            warningElement.innerHTML = `
                <p><strong>⚠️ Attention:</strong> Impossible de se connecter à l'API. Vérifiez que le serveur est démarré sur http://localhost:5000</p>
            `;
            
            // Ajouter des styles pour le message d'avertissement
            warningElement.style.backgroundColor = '#fff3cd';
            warningElement.style.color = '#856404';
            warningElement.style.padding = '10px';
            warningElement.style.borderRadius = '5px';
            warningElement.style.marginBottom = '20px';
            
            formSection.prepend(warningElement);
        }
    }
}

/**
 * Teste l'ajout d'un coureur directement via l'API
 */
async function testerAjoutCoureur() {
    try {
        // Demander l'ID de la course
        const courseId = prompt("Entrez l'ID de la course (par exemple: 1):", "1");
        if (!courseId) return;
        
        // Créer un coureur de test
        const coureurTest = {
            nom: "Test",
            prenom: "API",
            age: 25,
            poids: 70,
            numero_rfid: Math.floor(Math.random() * 9000000000) + 1000000000
        };
        
        console.log("Envoi direct à l'API:", coureurTest);
        
        // Envoyer directement à l'API sans passer par notre fonction
        const response = await fetch(`${API_BASE_URL}/courses/${courseId}/coureurs`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(coureurTest)
        });
        
        // Afficher les informations de la réponse
        console.log("Statut de la réponse:", response.status, response.statusText);
        console.log("Headers:", Object.fromEntries([...response.headers]));
        
        // Récupérer le corps de la réponse
        const responseText = await response.text();
        console.log("Corps de la réponse:", responseText);
        
        try {
            const responseData = JSON.parse(responseText);
            console.log("Données JSON:", responseData);
            
            if (response.ok) {
                alert(`✅ Coureur ajouté avec succès!\nNuméro RFID: ${coureurTest.numero_rfid}`);
            } else {
                alert(`⚠️ Erreur: ${responseData.message || "Erreur inconnue"}`);
            }
        } catch (e) {
            console.error("Erreur lors du parsing JSON:", e);
            alert(`⚠️ Réponse non-JSON reçue: ${responseText}`);
        }
    } catch (error) {
        console.error("Erreur lors du test:", error);
        alert(`❌ Erreur: ${error.message}`);
    }
}

/**
 * Initialise le formulaire d'inscription
 */
function initialiserFormulaire() {
    // Calculer l'âge automatiquement
    const dateNaissanceInput = document.getElementById('date-naissance');
    if (dateNaissanceInput) {
        dateNaissanceInput.addEventListener('change', function() {
            calculerAge();
        });
    }
    
    // Gérer la soumission du formulaire
    const inscriptionForm = document.getElementById('inscription-form');
    if (inscriptionForm) {
        inscriptionForm.addEventListener('submit', function(e) {
            e.preventDefault();
            inscrireCoureur();
        });
    }
    
    // Vérifier si une course est spécifiée dans l'URL
    const urlParams = new URLSearchParams(window.location.search);
    const courseId = urlParams.get('course');
    
    if (courseId) {
        // Sélectionner automatiquement la course spécifiée
        setTimeout(() => {
            const courseSelect = document.getElementById('course-selection');
            if (courseSelect) {
                courseSelect.value = courseId;
            }
        }, 500); // Attendre que le sélecteur soit rempli
    }
}

/**
 * Charge les courses disponibles et les ajoute au formulaire
 */
async function chargerCoursesDisponibles() {
    try {
        // Récupérer uniquement les courses actives
        const courses = await CourseAPI.getAll(true);
        
        if (courses.length > 0) {
            ajouterSelecteurCourse(courses);
        } else {
            console.log('Aucune course active trouvée');
            afficherMessageAucuneCourse();
        }
    } catch (error) {
        console.error('Erreur lors du chargement des courses:', error);
        afficherMessageErreur();
    }
}

/**
 * Ajoute un sélecteur de course au formulaire
 * @param {Array} courses - Liste des courses
 */
function ajouterSelecteurCourse(courses) {
    // Trouver l'emplacement où insérer le sélecteur
    const emailGroup = document.querySelector('input[name="email"]')?.closest('.form-group');
    
    if (!emailGroup) {
        console.error('Impossible de trouver l\'élément pour insérer le sélecteur de course');
        return;
    }
    
    // Créer le sélecteur
    const courseSelector = document.createElement('div');
    courseSelector.className = 'form-group';
    courseSelector.innerHTML = `
        <label for="course-selection">Course à laquelle vous souhaitez participer *</label>
        <select id="course-selection" name="course-selection" required>
            <option value="" selected disabled>Sélectionnez une course</option>
            ${courses.map(course => `
                <option value="${course.course_id}">
                    ${course.nom} - ${course.lieu} (${Utils.getTypeDescription(course)})
                </option>
            `).join('')}
        </select>
    `;
    
    // Insérer après le champ email
    emailGroup.parentNode.insertBefore(courseSelector, emailGroup.nextSibling);
}

/**
 * Affiche un message indiquant qu'aucune course n'est disponible
 */
function afficherMessageAucuneCourse() {
    const formSection = document.querySelector('.form-section');
    
    if (!formSection) {
        console.error('Impossible de trouver l\'élément pour afficher le message');
        return;
    }
    
    const messageElement = document.createElement('div');
    messageElement.className = 'no-courses-message';
    messageElement.innerHTML = `
        <h3>Aucune course disponible</h3>
        <p>Il n'y a actuellement aucune course ouverte aux inscriptions.</p>
        <a href="course.html" class="btn btn-secondary">Voir toutes les courses</a>
    `;
    
    formSection.appendChild(messageElement);
    
    // Désactiver le formulaire
    const form = document.getElementById('inscription-form');
    if (form) {
        const inputs = form.querySelectorAll('input, select, textarea, button[type="submit"]');
        inputs.forEach(input => {
            input.disabled = true;
        });
    }
}

/**
 * Affiche un message d'erreur
 */
function afficherMessageErreur() {
    const formSection = document.querySelector('.form-section');
    
    if (!formSection) {
        console.error('Impossible de trouver l\'élément pour afficher le message d\'erreur');
        return;
    }
    
    const messageElement = document.createElement('div');
    messageElement.className = 'error-message';
    messageElement.innerHTML = `
        <h3>Erreur de connexion</h3>
        <p>Impossible de charger les courses disponibles. Vérifiez que l'API est démarrée.</p>
        <button class="btn btn-secondary" onclick="chargerCoursesDisponibles()">Réessayer</button>
    `;
    
    formSection.appendChild(messageElement);
}

/**
 * Calcule l'âge à partir de la date de naissance
 */
function calculerAge() {
    const dateNaissance = document.getElementById('date-naissance').value;
    if (!dateNaissance) return;
    
    try {
        // Convertir le format jj/mm/aaaa en Date
        const parts = dateNaissance.split('/');
        if (parts.length === 3) {
            const birthDate = new Date(parts[2], parts[1] - 1, parts[0]);
            const today = new Date();
            let age = today.getFullYear() - birthDate.getFullYear();
            const monthDiff = today.getMonth() - birthDate.getMonth();
            
            if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
                age--;
            }
            
            // Vous pouvez utiliser cet âge pour la validation ou l'affichage
            console.log('Âge calculé:', age);
        }
    } catch (error) {
        console.error('Erreur lors du calcul de l\'âge:', error);
    }
}

/**
 * Calcule l'âge numérique à partir de la date de naissance
 * @returns {number} - Âge calculé
 */
function calculerAgeNumerique() {
    const dateNaissance = document.getElementById('date-naissance').value;
    if (!dateNaissance) return 20; // Valeur par défaut
    
    try {
        const parts = dateNaissance.split('/');
        if (parts.length === 3) {
            const birthDate = new Date(parts[2], parts[1] - 1, parts[0]);
            const today = new Date();
            let age = today.getFullYear() - birthDate.getFullYear();
            const monthDiff = today.getMonth() - birthDate.getMonth();
            
            if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
                age--;
            }
            
            return Math.max(age, 10); // Minimum 10 ans
        }
    } catch (error) {
        console.error('Erreur lors du calcul de l\'âge:', error);
    }
    
    return 20; // Valeur par défaut
}

/**
 * Génère un numéro RFID unique
 * @returns {number} - Numéro RFID (entier)
 */
function genererNumeroRFID() {
    // Générer un numéro aléatoire à 10 chiffres (format attendu par l'API)
    // Format: entier numérique sans préfixe
    const random = Math.floor(Math.random() * 9000000000) + 1000000000;
    return random; // Retourner un nombre, pas une chaîne
}

/**
 * Inscrit un coureur à une course
 */
async function inscrireCoureur() {
    // Récupérer l'ID de la course sélectionnée
    const courseSelect = document.getElementById('course-selection');
    if (!courseSelect) {
        alert('Veuillez sélectionner une course');
        return;
    }
    
    const courseId = courseSelect.value;
    if (!courseId) {
        alert('Veuillez sélectionner une course');
        return;
    }
    
    // Récupérer les données du formulaire
    const formData = {
        nom: document.getElementById('nom').value,
        prenom: document.getElementById('prenom').value,
        age: calculerAgeNumerique(),
        poids: parseFloat(document.getElementById('poids').value) || 70,
        taille: parseFloat(document.getElementById('taille').value) || 170,
        numero_rfid: genererNumeroRFID(),
        email: document.getElementById('email').value || '',
        telephone: document.getElementById('telephone').value || '',
        statut: document.getElementById('statut').value || 'externe',
        informations_medicales: document.getElementById('informations-medicales')?.value || ''
    };
    
    // Vérifications
    if (!formData.nom || !formData.prenom) {
        alert('Veuillez remplir tous les champs obligatoires');
        return;
    }
    
    if (formData.age < 10 || formData.age > 100) {
        alert('Âge invalide');
        return;
    }
    
    // Simplifier les données pour éviter les problèmes potentiels
    formData.nom = formData.nom.trim();
    formData.prenom = formData.prenom.trim();
    
    // S'assurer que le numéro RFID est une chaîne
    formData.numero_rfid = formData.numero_rfid.toString();
    
    console.log('Inscription du coureur:', formData);
    
    try {
        // Afficher un message de chargement
        const submitButton = document.querySelector('button[type="submit"]');
        const originalText = submitButton.textContent;
        submitButton.textContent = 'Inscription en cours...';
        submitButton.disabled = true;
        
        try {
            // Envoyer les données à l'API
            const response = await CourseAPI.addCoureur(courseId, formData);
            
            if (response.success) {
                alert(`Inscription réussie ! 🎉\n\nVotre numéro RFID: ${formData.numero_rfid}\n\nConservez ce numéro pour le jour de la course.`);
                document.getElementById('inscription-form').reset();
            } else {
                alert('Erreur lors de l\'inscription: ' + (response.message || 'Erreur inconnue'));
            }
        } finally {
            // Restaurer le bouton
            submitButton.textContent = originalText;
            submitButton.disabled = false;
        }
    } catch (error) {
        console.error('Erreur:', error);
        
        // Afficher un message d'erreur plus détaillé
        let errorMessage = 'Erreur de connexion avec le serveur. Vérifiez que l\'API est démarrée.';
        
        if (error.message) {
            errorMessage += '\n\nDétails: ' + error.message;
        }
        
        alert(errorMessage);
        
        // Afficher des informations de débogage dans la console
        console.log('Données envoyées:', {
            courseId: courseId,
            formData: formData
        });
    }
}