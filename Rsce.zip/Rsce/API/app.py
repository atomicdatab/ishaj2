from flask import Flask, jsonify
from flask_cors import CORS
from routes import api
import config
import traceback

def create_app():
    """Crée et configure l'application Flask"""
    app = Flask(__name__)
    app.config.from_object(config)
    
    # Activation de CORS pour permettre les requêtes cross-origin
    CORS(app)
    
    # Enregistrement des blueprints
    app.register_blueprint(api, url_prefix='/api')
    
    # Route d'accueil
    @app.route('/')
    def index():
        return jsonify({
            "message": "API d'administration des courses",
            "version": "1.0.0",
            "endpoints": {
                "courses": "/api/courses",
                "types_course": "/api/types-course",
                "badges": "/api/badges",
                "coureurs": "/api/coureurs"
            }
        })
    
    # Gestionnaire d'erreurs pour les routes non trouvées
    @app.errorhandler(404)
    def not_found(error):
        return jsonify({"success": False, "message": "Route non trouvée"}), 404
    
    # Gestionnaire d'erreurs pour les erreurs serveur
    @app.errorhandler(500)
    def server_error(error):
        print("ERREUR 500:")
        print(traceback.format_exc())
        return jsonify({"success": False, "message": "Erreur serveur interne"}), 500
    
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(host='0.0.0.0', port=5000, debug=config.DEBUG)