from flask import Blueprint, request, jsonify
from models import Course, Coureur, Badge, TypeCourse, PassageBadge
import bcrypt

api = Blueprint('api', __name__)

# Routes pour les courses
@api.route('/courses', methods=['GET'])
def get_courses():
    """Récupère toutes les courses"""
    active_only = request.args.get('active_only', 'false').lower() == 'true'
    courses = Course.get_all(active_only)
    return jsonify({"success": True, "data": courses})

@api.route('/courses/<int:course_id>', methods=['GET'])
def get_course(course_id):
    """Récupère une course par son ID"""
    course = Course.get_by_id(course_id)
    if not course:
        return jsonify({"success": False, "message": "Course non trouvée"}), 404
    return jsonify({"success": True, "data": course})

@api.route('/courses', methods=['POST'])
def create_course():
    """Crée une nouvelle course"""
    data = request.json
    
    # Vérification des champs obligatoires
    required_fields = ['nom', 'lieu', 'type_id']
    for field in required_fields:
        if field not in data:
            return jsonify({"success": False, "message": f"Le champ '{field}' est obligatoire"}), 400
    
    # Vérification du type de course
    type_id = data['type_id']
    type_course = TypeCourse.get_by_id(type_id)
    if not type_course:
        return jsonify({"success": False, "message": "Type de course invalide"}), 400
    
    # Vérification des champs spécifiques au type de course
    if type_course['nom'] == 'Temps' and 'temps_total' not in data:
        return jsonify({"success": False, "message": "Le champ 'temps_total' est obligatoire pour une course de type Temps"}), 400
    
    if type_course['nom'] == 'Distance' and 'distance_totale' not in data:
        return jsonify({"success": False, "message": "Le champ 'distance_totale' est obligatoire pour une course de type Distance"}), 400
    
    if 'distance_par_tour' not in data:
        return jsonify({"success": False, "message": "Le champ 'distance_par_tour' est obligatoire"}), 400
    
    # Création de la course
    course_id = Course.create(
        data['nom'],
        data['lieu'],
        data['type_id'],
        data.get('temps_total'),
        data.get('distance_totale'),
        data['distance_par_tour']
    )
    
    if not course_id:
        return jsonify({"success": False, "message": "Erreur lors de la création de la course"}), 500
    
    # Récupération de la course créée
    course = Course.get_by_id(course_id)
    return jsonify({"success": True, "message": "Course créée avec succès", "data": course}), 201

@api.route('/courses/<int:course_id>', methods=['PUT'])
def update_course(course_id):
    """Met à jour une course"""
    data = request.json
    
    # Vérification de l'existence de la course
    course = Course.get_by_id(course_id)
    if not course:
        return jsonify({"success": False, "message": "Course non trouvée"}), 404
    
    # Mise à jour de la course
    result = Course.update(
        course_id,
        data.get('nom'),
        data.get('lieu'),
        data.get('type_id'),
        data.get('temps_total'),
        data.get('distance_totale'),
        data.get('distance_par_tour')
    )
    
    if result is None:
        return jsonify({"success": False, "message": "Erreur lors de la mise à jour de la course"}), 500
    
    # Récupération de la course mise à jour
    updated_course = Course.get_by_id(course_id)
    return jsonify({"success": True, "message": "Course mise à jour avec succès", "data": updated_course})

@api.route('/courses/<int:course_id>', methods=['DELETE'])
def delete_course(course_id):
    """Supprime une course"""
    # Vérification de l'existence de la course
    course = Course.get_by_id(course_id)
    if not course:
        return jsonify({"success": False, "message": "Course non trouvée"}), 404
    
    # Suppression de la course
    result = Course.delete(course_id)
    if result is None:
        return jsonify({"success": False, "message": "Erreur lors de la suppression de la course"}), 500
    
    return jsonify({"success": True, "message": "Course supprimée avec succès"})

@api.route('/courses/<int:course_id>/coureurs', methods=['GET'])
def get_course_coureurs(course_id):
    """Récupère tous les coureurs inscrits à une course"""
    # Vérification de l'existence de la course
    course = Course.get_by_id(course_id)
    if not course:
        return jsonify({"success": False, "message": "Course non trouvée"}), 404
    
    coureurs = Course.get_coureurs(course_id)
    return jsonify({"success": True, "data": coureurs})

@api.route('/courses/<int:course_id>/coureurs', methods=['POST'])
def add_coureur_to_course(course_id):
    """Ajoute un coureur à une course"""
    import traceback
    import sys
    
    try:
        # Afficher les données reçues pour le débogage
        print(f"\n\n==== AJOUT COUREUR DEBUG ====")
        print(f"Course ID: {course_id}")
        print(f"Request Content-Type: {request.headers.get('Content-Type')}")
        print(f"Request data: {request.data.decode('utf-8') if request.data else 'Aucune donnée'}")
        
        # Récupérer les données JSON
        data = request.json
        print(f"Parsed JSON data: {data}")
        
        # Vérification de l'existence de la course
        course = Course.get_by_id(course_id)
        if not course:
            print(f"Erreur: Course {course_id} non trouvée")
            return jsonify({"success": False, "message": "Course non trouvée"}), 404
        
        print(f"Course trouvée: {course}")
        
        # Vérification des champs obligatoires
        required_fields = ['nom', 'prenom', 'age', 'poids', 'numero_rfid']
        missing_fields = []
        
        for field in required_fields:
            if field not in data:
                missing_fields.append(field)
        
        if missing_fields:
            print(f"Erreur: Champs manquants: {missing_fields}")
            return jsonify({"success": False, "message": f"Champs obligatoires manquants: {', '.join(missing_fields)}"}), 400
        
        # Vérifier les types de données
        try:
            nom = str(data['nom'])
            prenom = str(data['prenom'])
            age = int(data['age'])
            poids = float(data['poids'])
            numero_rfid = int(data['numero_rfid'])
            
            print(f"Données validées:")
            print(f"- Nom: {nom} (type: {type(nom)})")
            print(f"- Prénom: {prenom} (type: {type(prenom)})")
            print(f"- Âge: {age} (type: {type(age)})")
            print(f"- Poids: {poids} (type: {type(poids)})")
            print(f"- RFID: {numero_rfid} (type: {type(numero_rfid)})")
        except (ValueError, TypeError) as e:
            print(f"Erreur de conversion de type: {str(e)}")
            return jsonify({"success": False, "message": f"Erreur de format de données: {str(e)}"}), 400
        
        # Ajout du coureur à la course
        print(f"Appel de Course.ajouter_coureur avec les paramètres:")
        print(f"- course_id: {course_id}")
        print(f"- nom: {nom}")
        print(f"- prenom: {prenom}")
        print(f"- age: {age}")
        print(f"- poids: {poids}")
        print(f"- numero_rfid: {numero_rfid}")
        
        result = Course.ajouter_coureur(
            course_id,
            nom,
            prenom,
            age,
            poids,
            numero_rfid
        )
        
        print(f"Résultat de l'appel: {result}")
        
        if result is None:
            print("Erreur: L'appel à ajouter_coureur a retourné None")
            return jsonify({"success": False, "message": "Erreur lors de l'ajout du coureur à la course"}), 500
        
        print("Succès: Coureur ajouté avec succès")
        return jsonify({"success": True, "message": "Coureur ajouté à la course avec succès"})
    
    except Exception as e:
        # Capturer et afficher l'erreur complète
        print(f"\n\n==== ERREUR CRITIQUE ====")
        print(f"Type d'erreur: {type(e).__name__}")
        print(f"Message d'erreur: {str(e)}")
        print(f"Traceback complet:")
        traceback.print_exc(file=sys.stdout)
        print(f"==== FIN ERREUR ====\n\n")
        
        # Retourner une réponse d'erreur détaillée
        error_details = {
            "success": False,
            "message": "Erreur serveur lors de l'ajout du coureur",
            "error_type": type(e).__name__,
            "error_details": str(e)
        }
        return jsonify(error_details), 500

# Routes pour les types de course
@api.route('/types-course', methods=['GET'])
def get_types_course():
    """Récupère tous les types de course"""
    types = TypeCourse.get_all()
    return jsonify({"success": True, "data": types})

# Routes pour les badges
@api.route('/badges', methods=['GET'])
def get_badges():
    """Récupère tous les badges"""
    badges = Badge.get_all()
    return jsonify({"success": True, "data": badges})

@api.route('/badges/<int:badge_id>', methods=['GET'])
def get_badge(badge_id):
    """Récupère un badge par son ID"""
    badge = Badge.get_by_id(badge_id)
    if not badge:
        return jsonify({"success": False, "message": "Badge non trouvé"}), 404
    return jsonify({"success": True, "data": badge})

# Routes pour les coureurs
@api.route('/coureurs', methods=['GET'])
def get_coureurs():
    """Récupère tous les coureurs"""
    coureurs = Coureur.get_all()
    return jsonify({"success": True, "data": coureurs})

@api.route('/coureurs/<int:coureur_id>', methods=['GET'])
def get_coureur(coureur_id):
    """Récupère un coureur par son ID"""
    coureur = Coureur.get_by_id(coureur_id)
    if not coureur:
        return jsonify({"success": False, "message": "Coureur non trouvé"}), 404
    return jsonify({"success": True, "data": coureur})

# Routes pour les passages de badge
@api.route('/courses/<int:course_id>/passages', methods=['GET'])
def get_passages(course_id):
    """Récupère tous les passages de badge pour une course"""
    # Vérification de l'existence de la course
    course = Course.get_by_id(course_id)
    if not course:
        return jsonify({"success": False, "message": "Course non trouvée"}), 404
    
    passages = PassageBadge.get_by_course(course_id)
    return jsonify({"success": True, "data": passages})

@api.route('/courses/<int:course_id>/passages', methods=['POST'])
def add_passage(course_id):
    """Enregistre un passage de badge"""
    data = request.json
    
    # Vérification de l'existence de la course
    course = Course.get_by_id(course_id)
    if not course:
        return jsonify({"success": False, "message": "Course non trouvée"}), 404
    
    # Vérification des champs obligatoires
    required_fields = ['numero_rfid', 'numero_tour']
    for field in required_fields:
        if field not in data:
            return jsonify({"success": False, "message": f"Le champ '{field}' est obligatoire"}), 400
    
    # Enregistrement du passage
    result = PassageBadge.enregistrer_passage(
        course_id,
        data['numero_rfid'],
        data['numero_tour']
    )
    
    if result is None:
        return jsonify({"success": False, "message": "Erreur lors de l'enregistrement du passage"}), 500
    
    return jsonify({"success": True, "message": "Passage enregistré avec succès"})

# Ajouter cet import en haut du fichier routes.py
import bcrypt

# Ajouter cette route avec les autres routes dans routes.py
@api.route('/login', methods=['POST'])
def login():
    """Authentification administrateur"""
    try:
        data = request.json
        
        # Vérification des champs obligatoires
        if not data or 'username' not in data or 'password' not in data:
            return jsonify({"success": False, "message": "Username et password requis"}), 400
        
        username = data['username']
        password = data['password']
        
        # Récupérer l'administrateur de la base de données
        from database import execute_query
        query = "SELECT admin_id, username, password_hash FROM administrateurs WHERE username = %s"
        result = execute_query(query, (username,))
        
        if not result:
            return jsonify({"success": False, "message": "Identifiants incorrects"}), 401
        
        admin = result[0]
        
        # Vérifier le mot de passe avec bcrypt
        if bcrypt.checkpw(password.encode('utf-8'), admin['password_hash'].encode('utf-8')):
            # Mot de passe correct
            return jsonify({
                "success": True, 
                "message": "Connexion réussie",
                "admin": {
                    "id": admin['admin_id'],
                    "username": admin['username']
                }
            })
        else:
            # Mot de passe incorrect
            return jsonify({"success": False, "message": "Identifiants incorrects"}), 401
            
    except Exception as e:
        print(f"Erreur lors de la connexion: {e}")
        return jsonify({"success": False, "message": "Erreur serveur"}), 500

@api.route('/verify-session', methods=['GET'])
def verify_session():
    """Vérifie si l'utilisateur est connecté (pour les vérifications côté client)"""
    # Pour l'instant, on retourne toujours true
    # En production, on vérifierait un vrai token/session
    return jsonify({"success": True, "message": "Session valide"})