"""
Script pour vérifier la structure de la procédure stockée AjouterCoureurCourse
"""

import mysql.connector
from mysql.connector import Error
from config import DB_CONFIG

def check_procedure():
    """Vérifie la structure de la procédure stockée AjouterCoureurCourse"""
    connection = None
    cursor = None
    
    try:
        # Connexion à la base de données
        connection = mysql.connector.connect(
            host=DB_CONFIG['host'],
            user=DB_CONFIG['user'],
            password=DB_CONFIG['password'],
            database=DB_CONFIG['database']
        )
        
        if connection.is_connected():
            print(f"✅ Connexion à la base de données réussie")
            
            cursor = connection.cursor(dictionary=True)
            
            # Vérifier si la procédure existe
            cursor.execute("""
                SHOW PROCEDURE STATUS 
                WHERE Db = %s AND Name = %s
            """, (DB_CONFIG['database'], 'AjouterCoureurCourse'))
            
            procedure = cursor.fetchone()
            
            if procedure:
                print(f"✅ La procédure 'AjouterCoureurCourse' existe")
                print(f"Détails: {procedure}")
                
                # Récupérer la définition de la procédure
                cursor.execute("""
                    SHOW CREATE PROCEDURE AjouterCoureurCourse
                """)
                
                definition = cursor.fetchone()
                
                if definition:
                    print("\n=== DÉFINITION DE LA PROCÉDURE ===")
                    print(definition['Create Procedure'])
                    print("=== FIN DE LA DÉFINITION ===\n")
                    
                    # Analyser les paramètres
                    create_proc = definition['Create Procedure']
                    start_params = create_proc.find('(')
                    end_params = create_proc.find(')', start_params)
                    
                    if start_params > 0 and end_params > start_params:
                        params_str = create_proc[start_params+1:end_params]
                        params = [p.strip() for p in params_str.split(',')]
                        
                        print("Paramètres de la procédure:")
                        for i, param in enumerate(params):
                            print(f"{i+1}. {param}")
                        
                        # Vérifier l'ordre des paramètres
                        expected_order = ['nom', 'prenom', 'age', 'poids', 'numero_rfid', 'course_id']
                        actual_order = []
                        
                        for param in params:
                            for expected in expected_order:
                                if expected in param.lower():
                                    actual_order.append(expected)
                                    break
                        
                        print(f"\nOrdre attendu des paramètres: {expected_order}")
                        print(f"Ordre détecté des paramètres: {actual_order}")
                        
                        if actual_order == expected_order:
                            print("✅ L'ordre des paramètres semble correct")
                        else:
                            print("⚠️ L'ordre des paramètres semble différent de celui attendu")
                            
                            # Suggérer l'ordre correct
                            print("\nOrdre correct d'appel de la procédure:")
                            print("call_procedure('AjouterCoureurCourse', (nom, prenom, age, poids, numero_rfid, course_id))")
                else:
                    print("❌ Impossible de récupérer la définition de la procédure")
            else:
                print("❌ La procédure 'AjouterCoureurCourse' n'existe pas")
                
                # Vérifier les autres procédures
                cursor.execute("""
                    SHOW PROCEDURE STATUS 
                    WHERE Db = %s
                """, (DB_CONFIG['database'],))
                
                procedures = cursor.fetchall()
                
                if procedures:
                    print("\nProcédures disponibles:")
                    for proc in procedures:
                        print(f"- {proc['Name']}")
                else:
                    print("Aucune procédure stockée trouvée dans la base de données")
    
    except Error as e:
        print(f"❌ Erreur lors de la connexion à MySQL: {e}")
    
    finally:
        if cursor:
            cursor.close()
        if connection and connection.is_connected():
            connection.close()
            print("Connexion à la base de données fermée")

if __name__ == "__main__":
    check_procedure()