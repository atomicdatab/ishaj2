# API d'Administration des Courses

API RESTful pour la gestion des courses, des coureurs et des badges RFID.

## Installation

1. Cloner le dépôt
2. Installer les dépendances :
   ```
   pip install -r requirements.txt
   ```
3. Configurer la base de données MySQL :
   - Créer la base de données en exécutant le script `db.sql`
   - Vérifier les paramètres de connexion dans `config.py`

## Démarrage

```
python app.py
```

L'API sera accessible à l'adresse : http://localhost:5000

## Endpoints de l'API

### Courses

- `GET /api/courses` - Récupérer toutes les courses
- `GET /api/courses?active_only=true` - Récupérer uniquement les courses actives
- `GET /api/courses/{id}` - Récupérer une course par son ID
- `POST /api/courses` - Créer une nouvelle course
- `PUT /api/courses/{id}` - Mettre à jour une course
- `DELETE /api/courses/{id}` - Supprimer une course

### Coureurs

- `GET /api/coureurs` - Récupérer tous les coureurs
- `GET /api/coureurs/{id}` - Récupérer un coureur par son ID
- `GET /api/courses/{id}/coureurs` - Récupérer les coureurs d'une course
- `POST /api/courses/{id}/coureurs` - Ajouter un coureur à une course

### Types de course

- `GET /api/types-course` - Récupérer tous les types de course

### Badges

- `GET /api/badges` - Récupérer tous les badges
- `GET /api/badges/{id}` - Récupérer un badge par son ID

### Passages de badge

- `GET /api/courses/{id}/passages` - Récupérer les passages de badge d'une course
- `POST /api/courses/{id}/passages` - Enregistrer un passage de badge

## Exemples d'utilisation

### Créer une course

```json
POST /api/courses
{
  "nom": "Marathon de Paris",
  "lieu": "Paris",
  "type_id": 2,
  "distance_totale": 42195,
  "distance_par_tour": 42195
}
```

### Ajouter un coureur à une course

```json
POST /api/courses/1/coureurs
{
  "nom": "Dupont",
  "prenom": "Jean",
  "age": 35,
  "poids": 75.5,
  "numero_rfid": "ABC123456"
}
```

### Enregistrer un passage de badge

```json
POST /api/courses/1/passages
{
  "numero_rfid": "ABC123456",
  "numero_tour": 1
}
```