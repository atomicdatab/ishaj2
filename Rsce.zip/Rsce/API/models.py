from database import execute_query, call_procedure

class Badge:
    @staticmethod
    def get_all():
        """Récupère tous les badges"""
        query = "SELECT * FROM Badges"
        return execute_query(query)
    
    @staticmethod
    def get_by_id(badge_id):
        """Récupère un badge par son ID"""
        query = "SELECT * FROM Badges WHERE badge_id = %s"
        result = execute_query(query, (badge_id,))
        return result[0] if result else None
    
    @staticmethod
    def get_by_rfid(numero_rfid):
        """Récupère un badge par son numéro RFID"""
        query = "SELECT * FROM Badges WHERE numero_rfid = %s"
        result = execute_query(query, (numero_rfid,))
        return result[0] if result else None
    
    @staticmethod
    def create(numero_rfid, est_actif=True):
        """Crée un nouveau badge"""
        query = "INSERT INTO Badges (numero_rfid, est_actif) VALUES (%s, %s)"
        return execute_query(query, (numero_rfid, est_actif))
    
    @staticmethod
    def update(badge_id, numero_rfid=None, est_actif=None):
        """Met à jour un badge"""
        current = Badge.get_by_id(badge_id)
        if not current:
            return None
            
        new_rfid = numero_rfid if numero_rfid is not None else current['numero_rfid']
        new_actif = est_actif if est_actif is not None else current['est_actif']
        
        query = "UPDATE Badges SET numero_rfid = %s, est_actif = %s WHERE badge_id = %s"
        return execute_query(query, (new_rfid, new_actif, badge_id))

class Coureur:
    @staticmethod
    def get_all():
        """Récupère tous les coureurs"""
        query = """
            SELECT c.*, b.numero_rfid 
            FROM Coureurs c
            LEFT JOIN Badges b ON c.badge_id = b.badge_id
        """
        return execute_query(query)
    
    @staticmethod
    def get_by_id(coureur_id):
        """Récupère un coureur par son ID"""
        query = """
            SELECT c.*, b.numero_rfid 
            FROM Coureurs c
            LEFT JOIN Badges b ON c.badge_id = b.badge_id
            WHERE c.coureur_id = %s
        """
        result = execute_query(query, (coureur_id,))
        return result[0] if result else None
    
    @staticmethod
    def create(nom, prenom, age, poids, badge_id=None):
        """Crée un nouveau coureur"""
        query = """
            INSERT INTO Coureurs (nom, prenom, age, poids, badge_id) 
            VALUES (%s, %s, %s, %s, %s)
        """
        return execute_query(query, (nom, prenom, age, poids, badge_id))
    
    @staticmethod
    def update(coureur_id, nom=None, prenom=None, age=None, poids=None, badge_id=None):
        """Met à jour un coureur"""
        current = Coureur.get_by_id(coureur_id)
        if not current:
            return None
            
        new_nom = nom if nom is not None else current['nom']
        new_prenom = prenom if prenom is not None else current['prenom']
        new_age = age if age is not None else current['age']
        new_poids = poids if poids is not None else current['poids']
        new_badge_id = badge_id if badge_id is not None else current['badge_id']
        
        query = """
            UPDATE Coureurs 
            SET nom = %s, prenom = %s, age = %s, poids = %s, badge_id = %s 
            WHERE coureur_id = %s
        """
        return execute_query(query, (new_nom, new_prenom, new_age, new_poids, new_badge_id, coureur_id))

class TypeCourse:
    @staticmethod
    def get_all():
        """Récupère tous les types de course"""
        query = "SELECT * FROM TypesCourse"
        return execute_query(query)
    
    @staticmethod
    def get_by_id(type_id):
        """Récupère un type de course par son ID"""
        query = "SELECT * FROM TypesCourse WHERE type_id = %s"
        result = execute_query(query, (type_id,))
        return result[0] if result else None

class Course:
    @staticmethod
    def get_all(active_only=False):
        """Récupère toutes les courses"""
        query = """
            SELECT c.*, t.nom as type_nom, t.description as type_description
            FROM Courses c
            JOIN TypesCourse t ON c.type_id = t.type_id
        """
        if active_only:
            query += " WHERE c.est_active = TRUE"
        return execute_query(query)
    
    @staticmethod
    def get_by_id(course_id):
        """Récupère une course par son ID"""
        query = """
            SELECT c.*, t.nom as type_nom, t.description as type_description
            FROM Courses c
            JOIN TypesCourse t ON c.type_id = t.type_id
            WHERE c.course_id = %s
        """
        result = execute_query(query, (course_id,))
        return result[0] if result else None
    
    @staticmethod
    def create(nom, lieu, type_id, temps_total=None, distance_totale=None, distance_par_tour=0):
        """Crée une nouvelle course en utilisant la procédure stockée"""
        return call_procedure('CreerCourse', (nom, lieu, type_id, temps_total, distance_totale, distance_par_tour))
    
    @staticmethod
    def update(course_id, nom=None, lieu=None, type_id=None, temps_total=None, distance_totale=None, distance_par_tour=None):
        """Met à jour une course en utilisant la procédure stockée"""
        current = Course.get_by_id(course_id)
        if not current:
            return None
            
        new_nom = nom if nom is not None else current['nom']
        new_lieu = lieu if lieu is not None else current['lieu']
        new_type_id = type_id if type_id is not None else current['type_id']
        new_temps_total = temps_total if temps_total is not None else current['temps_total']
        new_distance_totale = distance_totale if distance_totale is not None else current['distance_totale']
        new_distance_par_tour = distance_par_tour if distance_par_tour is not None else current['distance_par_tour']
        
        return call_procedure('ModifierCourse', (course_id, new_nom, new_lieu, new_type_id, new_temps_total, new_distance_totale, new_distance_par_tour))
    
    @staticmethod
    def delete(course_id):
        """Supprime une course en utilisant la procédure stockée"""
        return call_procedure('SupprimerCourse', (course_id,))
    
    @staticmethod
    def get_coureurs(course_id):
        """Récupère tous les coureurs inscrits à une course"""
        query = """
            SELECT c.*, cr.*, b.numero_rfid
            FROM InscriptionsCourse ic
            JOIN Coureurs cr ON ic.coureur_id = cr.coureur_id
            JOIN Courses c ON ic.course_id = c.course_id
            LEFT JOIN Badges b ON cr.badge_id = b.badge_id
            WHERE ic.course_id = %s
        """
        return execute_query(query, (course_id,))
    
    @staticmethod
    def ajouter_coureur(course_id, nom, prenom, age, poids, numero_rfid):
        """Ajoute un coureur à une course en utilisant la procédure stockée"""
        import traceback
        import sys
        
        try:
            print(f"\n==== DEBUG AJOUTER_COUREUR ====")
            print(f"Paramètres reçus:")
            print(f"- course_id: {course_id} (type: {type(course_id)})")
            print(f"- nom: {nom} (type: {type(nom)})")
            print(f"- prenom: {prenom} (type: {type(prenom)})")
            print(f"- age: {age} (type: {type(age)})")
            print(f"- poids: {poids} (type: {type(poids)})")
            print(f"- numero_rfid: {numero_rfid} (type: {type(numero_rfid)})")
            
            # Vérifier si le coureur existe déjà avec ce numéro RFID
            from database import execute_query
            query = "SELECT * FROM Badges WHERE numero_rfid = %s"
            existing_badge = execute_query(query, (numero_rfid,))
            
            if existing_badge:
                print(f"Badge existant trouvé avec RFID {numero_rfid}: {existing_badge}")
            else:
                print(f"Aucun badge existant avec RFID {numero_rfid}")
            
            # Appeler la procédure stockée
            print(f"Appel de la procédure 'AjouterCoureurCourse' avec les paramètres:")
            params = (nom, prenom, age, poids, numero_rfid, course_id)
            print(f"Paramètres: {params}")
            
            result = call_procedure('AjouterCoureurCourse', params)
            
            print(f"Résultat de l'appel à la procédure: {result}")
            print(f"==== FIN DEBUG AJOUTER_COUREUR ====\n")
            
            return result
        except Exception as e:
            print(f"\n==== ERREUR DANS AJOUTER_COUREUR ====")
            print(f"Type d'erreur: {type(e).__name__}")
            print(f"Message d'erreur: {str(e)}")
            print(f"Traceback complet:")
            traceback.print_exc(file=sys.stdout)
            print(f"==== FIN ERREUR AJOUTER_COUREUR ====\n")
            
            # Propager l'erreur
            raise

class PassageBadge:
    @staticmethod
    def get_by_course(course_id):
        """Récupère tous les passages de badge pour une course"""
        query = """
            SELECT pb.*, b.numero_rfid, c.nom as nom_course
            FROM PassagesBadges pb
            JOIN Badges b ON pb.badge_id = b.badge_id
            JOIN Courses c ON pb.course_id = c.course_id
            WHERE pb.course_id = %s
            ORDER BY pb.temps_passage
        """
        return execute_query(query, (course_id,))
    
    @staticmethod
    def enregistrer_passage(course_id, numero_rfid, numero_tour):
        """Enregistre un passage de badge en utilisant la procédure stockée"""
        return call_procedure('EnregistrerPassageBadge', (course_id, numero_rfid, numero_tour))