import bcrypt
import mysql.connector
from config import DB_CONFIG

# Mot de passe à hasher
password = "admin2025"

# Générer le hash
password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

print(f"Mot de passe: {password}")
print(f"Hash généré: {password_hash.decode('utf-8')}")

# Connexion à la base de données
try:
    connection = mysql.connector.connect(
        host=DB_CONFIG['host'],
        user=DB_CONFIG['user'], 
        password=DB_CONFIG['password'],
        database=DB_CONFIG['database']
    )
    
    cursor = connection.cursor()
    
    # Insérer l'administrateur
    query = "INSERT INTO administrateurs (username, password_hash) VALUES (%s, %s)"
    cursor.execute(query, ("admin", password_hash.decode('utf-8')))
    
    connection.commit()
    print("✅ Administrateur créé avec succès!")
    
except Exception as e:
    print(f"❌ Erreur: {e}")
    
finally:
    if connection and connection.is_connected():
        cursor.close()
        connection.close()
        print("Connexion fermée")