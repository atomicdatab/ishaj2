import mysql.connector
from mysql.connector import Error
from config import DB_CONFIG

def get_db_connection():
    """
    Établit une connexion à la base de données MySQL
    """
    try:
        connection = mysql.connector.connect(
            host=DB_CONFIG['host'],
            user=DB_CONFIG['user'],
            password=DB_CONFIG['password'],
            database=DB_CONFIG['database']
        )
        return connection
    except Error as e:
        print(f"Erreur lors de la connexion à MySQL: {e}")
        return None

def execute_query(query, params=None, fetch=False):
    """
    Exécute une requête SQL
    
    Args:
        query (str): Requête SQL à exécuter
        params (tuple, optional): Paramètres pour la requête
        fetch (bool, optional): Si True, retourne les résultats de la requête
        
    Returns:
        list/int: Résultats de la requête ou ID de la dernière insertion
    """
    connection = get_db_connection()
    cursor = None
    result = None
    
    try:
        if connection:
            cursor = connection.cursor(dictionary=True)
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)
                
            if query.strip().upper().startswith("SELECT") or fetch:
                result = cursor.fetchall()
            else:
                connection.commit()
                if cursor.lastrowid:
                    result = cursor.lastrowid
                else:
                    result = cursor.rowcount
    except Error as e:
        print(f"Erreur lors de l'exécution de la requête: {e}")
        if connection:
            connection.rollback()
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()
            
    return result

def call_procedure(procedure_name, params=None):
    """
    Appelle une procédure stockée
    
    Args:
        procedure_name (str): Nom de la procédure stockée
        params (tuple, optional): Paramètres pour la procédure
        
    Returns:
        list/None: Résultats de la procédure ou None en cas d'erreur
    """
    import traceback
    import sys
    
    connection = get_db_connection()
    cursor = None
    result = None
    
    print(f"\n==== APPEL PROCÉDURE {procedure_name} ====")
    print(f"Paramètres: {params}")
    
    if not connection:
        print(f"ERREUR: Impossible d'établir une connexion à la base de données")
        return None
    
    try:
        cursor = connection.cursor(dictionary=True)
        
        # Vérifier si la procédure existe
        cursor.execute("SHOW PROCEDURE STATUS WHERE Db = %s AND Name = %s", 
                      (DB_CONFIG['database'], procedure_name))
        procedure_exists = cursor.fetchone()
        
        if not procedure_exists:
            print(f"ERREUR: La procédure '{procedure_name}' n'existe pas dans la base de données")
            return None
        
        print(f"Procédure trouvée: {procedure_exists}")
        
        # Appeler la procédure
        print(f"Appel de la procédure avec cursor.callproc...")
        
        if params:
            cursor.callproc(procedure_name, params)
        else:
            cursor.callproc(procedure_name)
        
        print(f"Appel réussi, récupération des résultats...")
        
        # Récupérer les résultats si la procédure retourne des données
        stored_results = list(cursor.stored_results())
        print(f"Nombre de résultats stockés: {len(stored_results)}")
        
        for i, result_cursor in enumerate(stored_results):
            result_set = result_cursor.fetchall()
            print(f"Résultat {i+1}: {result_set}")
            result = result_set  # Garder le dernier résultat
        
        print(f"Validation des modifications (commit)...")
        connection.commit()
        print(f"Commit réussi")
        
        # Si aucun résultat n'a été retourné mais que l'opération a réussi
        if result is None:
            result = True  # Indiquer que l'opération a réussi
        
        print(f"Résultat final: {result}")
        
    except Error as e:
        print(f"ERREUR MySQL lors de l'appel de la procédure {procedure_name}: {e}")
        print(f"Code d'erreur MySQL: {e.errno}")
        print(f"Message d'erreur MySQL: {e.msg}")
        print(f"Traceback complet:")
        traceback.print_exc(file=sys.stdout)
        
        if connection:
            print(f"Annulation des modifications (rollback)...")
            connection.rollback()
        
        # Propager l'erreur pour un meilleur débogage
        raise
        
    except Exception as e:
        print(f"ERREUR GÉNÉRALE lors de l'appel de la procédure {procedure_name}: {e}")
        print(f"Type d'erreur: {type(e).__name__}")
        print(f"Traceback complet:")
        traceback.print_exc(file=sys.stdout)
        
        if connection:
            print(f"Annulation des modifications (rollback)...")
            connection.rollback()
        
        # Propager l'erreur pour un meilleur débogage
        raise
        
    finally:
        if cursor:
            cursor.close()
            print(f"Curseur fermé")
        if connection:
            connection.close()
            print(f"Connexion fermée")
        
        print(f"==== FIN APPEL PROCÉDURE {procedure_name} ====\n")
            
    return result